const API_BASE_URL = "http://127.0.0.1:8000/api";

export interface IssuePayload {
  title: string;
  category: string;
  description: string;
  location?: string;
}

// Fetch all reported issues from Python FastAPI
export const fetchIssues = async () => {
  const response = await fetch(`${API_BASE_URL}/issues`);
  if (!response.ok) throw new Error("Failed to fetch issues");
  return await response.json();
};

// Post a new issue to Python FastAPI
export const createIssue = async (issueData: IssuePayload) => {
  const response = await fetch(`${API_BASE_URL}/issues`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(issueData),
  });
  if (!response.ok) throw new Error("Failed to create issue");
  return await response.json();
};