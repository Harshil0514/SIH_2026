from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from database import get_db_connection, init_db

app = FastAPI(title="CIVICSETU API", version="1.0")

# Initialize database schema on app start
init_db()

# Enable Cross-Origin Resource Sharing (CORS) for React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Adjust in production to frontend domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pydantic schema for request body validation
class IssueCreate(BaseModel):
    title: str
    category: str
    description: str
    location: str = "Unspecified"

# Helper function: Basic keyword-based analysis engine
def analyze_issue(description: str) -> str:
    desc = description.lower()
    if "water" in desc or "leak" in desc or "pipe" in desc:
        return "Priority: High | Dept: Water Supply & Sanitation"
    elif "road" in desc or "pothole" in desc or "crack" in desc:
        return "Priority: High | Dept: Public Works Department (PWD)"
    elif "garbage" in desc or "trash" in desc or "waste" in desc:
        return "Priority: Medium | Dept: Municipal Solid Waste"
    elif "light" in desc or "dark" in desc or "electricity" in desc:
        return "Priority: Medium | Dept: Electrical & Lighting"
    else:
        return "Priority: Normal | Dept: General Civic Administration"

@app.get("/")
def read_root():
    return {"message": "CIVICSETU Backend Operational"}

@app.get("/api/issues")
def fetch_all_issues():
    """Fetch all reported issues from SQLite."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM issues ORDER BY id DESC")
    rows = cursor.fetchall()
    conn.close()
    
    issues = [dict(row) for row in rows]
    return {"status": "success", "data": issues}

@app.post("/api/issues")
def create_new_issue(issue: IssueCreate):
    """Save a new issue and auto-generate AI categorization."""
    ai_result = analyze_issue(issue.description)
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        """
        INSERT INTO issues (title, category, description, location, ai_summary)
        VALUES (?, ?, ?, ?, ?)
        """,
        (issue.title, issue.category, issue.description, issue.location, ai_result)
    )
    conn.commit()
    new_id = cursor.lastrowid
    conn.close()
    
    return {
        "status": "success",
        "data": {
            "id": new_id,
            "title": issue.title,
            "category": issue.category,
            "description": issue.description,
            "location": issue.location,
            "status": "Open",
            "ai_summary": ai_result
        }
    }